<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use Session;
use Illuminate\Support\Facades\Redirect;
Session_start();


class CheckoutController extends Controller
{
    public function index()
    {
    	return view('pages.checkout');
    }
    public function login_check()
    {
    	return view('pages.login');
    }
    public function customer_regestration(Request $request)
    {
		$data=array();
    	$data['customer_name']=$request->customer_name;
    	$data['business_trading']=$request->business_trading;
    	$data['customer_email']=$request->customer_email;
    	$data['username']=$request->username;
    	$data['password']=md5($request->password);

    	$customer_id=DB::table('tbl_customer')
    	->insertGetId($data);
    	Session::put('customer_id',$customer_id);
    	Session::put('customer_name',$request->customer_name);
    	Session::put('message','Account Created Successfully !!');
    	return Redirect::to('/checkout');
    }

    public function save_shipping(Request $request)
    {
		$data=array();
    	$data['first_name']=$request->first_name;
    	$data['last_name']=$request->last_name;
    	$data['business_legal']=$request->business_legal;
    	$data['address']=$request->address;
    	$data['country']=$request->country;
    	$data['customer_email']=$request->customer_email;
    	$data['post_code']=$request->post_code;
    	$data['phone_no']=$request->phone_no;

		$data['payment_gateway']=$request->payment_gateway;


    	$shipping_id=DB::table('tbl_shipping')
    	->insertGetId($data);
    	Session::put('shipping_id',$shipping_id);
    	Session::put('message','Order Submited Successfully !!');
    	return Redirect::to('/complete');
    }


    public function customer_login(Request $request){

    	$customer_email=$request->customer_email;
    	$password=md5($request->password);
    	$result = DB::table('tbl_customer')
    		->where('customer_email', $customer_email)
    		->where('password', $password)
    		->first();

    		if ($result) {
    			
    			Session::put('customer_id', $result->customer_id);
    			return Redirect::to('/checkout');
    		}else{
    			return Redirect::to('/login_check');
    		}
    }

    public function customer_logout(){

    	Session::flush();
    	return Redirect::to('/login-check');
    }

  


}
