<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use Session;
use Illuminate\Support\Facades\Redirect;

class HomeController extends Controller
{
  	public function index()
  	{

        $all_product=DB::table('tbl_products')->get();
        $manage_product=view('pages.home_content')
            ->with('all_product', $all_product);
            return view('index')
            ->with('pages.home_content',$manage_product);

  		//return view('pages.home_content');
  	}
  	public function shop()
  	{
       $all_product=DB::table('tbl_products')->get();
        $manage_product=view('pages.shop')
            ->with('all_product', $all_product);
            return view('index')
            ->with('pages.shop',$manage_product);
  		// return view('pages.shop');
  	}
  	public function music()
  	{
  		return view('pages.music');
  	}
  	public function contact_us()
  	{
  		return view('pages.contact_us');
  	}
  	public function faq()
  	{
  		return view('pages.faq');
  	}
  	public function my_account()
  	{
  		return view('pages.my_account');
  	}



    public function product_details($product_id)
    {
        $product_by_details=DB::table('tbl_products')
                  
                  ->where('tbl_products.product_id', $product_id)
                  ->where('tbl_products.publication_status', 1)
                  ->first();
            $manage_product_by_details=view('pages.product_details')
            ->with('product_by_details', $product_by_details);
            return view('index')
            ->with('pages.product_details',$manage_product_by_details);
    }
}
